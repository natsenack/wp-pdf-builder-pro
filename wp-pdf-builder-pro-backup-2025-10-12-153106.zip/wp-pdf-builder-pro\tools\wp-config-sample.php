<?php
/**
 * Configuration WordPress pour le développement - PDF Builder Pro
 * Copiez ce fichier vers wp-config.php et ajustez les valeurs
 */

// ** Paramètres MySQL - Vous devez les modifier ! ** //
/** Nom de la base de données de WordPress. */
define( 'DB_NAME', 'database_name_here' );

/** Utilisateur de la base de données MySQL. */
define( 'DB_USER', 'username_here' );

/** Mot de passe de la base de données MySQL. */
define( 'DB_PASSWORD', 'password_here' );

/** Adresse de l'hébergement MySQL. */
define( 'DB_HOST', 'localhost' );

/** Jeu de caractères à utiliser par la base de données lors de la création des tables. */
define( 'DB_CHARSET', 'utf8' );

/** Type de collation de la base de données.
  * N'y touchez que si vous savez ce que vous faites !
  */
define( 'DB_COLLATE', '' );

// ** Clés uniques d'authentification et salage. ** //
/** Changez ces valeurs ! **/
define( 'AUTH_KEY',         'put your unique phrase here' );
define( 'SECURE_AUTH_KEY',  'put your unique phrase here' );
define( 'LOGGED_IN_KEY',    'put your unique phrase here' );
define( 'NONCE_KEY',        'put your unique phrase here' );
define( 'AUTH_SALT',        'put your unique phrase here' );
define( 'SECURE_AUTH_SALT', 'put your unique phrase here' );
define( 'LOGGED_IN_SALT',   'put your unique phrase here' );
define( 'NONCE_SALT',       'put your unique phrase here' );

// ** Configuration PDF Builder Pro ** //
/** Mode debug pour le développement */
define( 'WP_DEBUG', true );
define( 'WP_DEBUG_LOG', true );
define( 'PDF_BUILDER_DEBUG', true );
define( 'PDF_BUILDER_DEBUG_MODE', true );

// ** Configuration avancée ** //
/** Limite mémoire PHP */
define( 'WP_MEMORY_LIMIT', '256M' );
define( 'WP_MAX_MEMORY_LIMIT', '512M' );

// ** Sécurité ** //
/** Désactiver l'édition de fichiers */
define( 'DISALLOW_FILE_EDIT', true );
define( 'DISALLOW_FILE_MODS', false );

// ** Performance ** //
/** Cache objet */
define( 'WP_CACHE', false );

// ** URLs ** //
/** Adresse WordPress (sans slash final) */
define( 'WP_SITEURL', 'http://localhost/wp-pdf-builder-pro' );
define( 'WP_HOME', 'http://localhost/wp-pdf-builder-pro' );

// ** Table prefix ** //
$table_prefix = 'wp_';

// ** Configuration multisite - N'activez que si nécessaire ** //
/*
define( 'WP_ALLOW_MULTISITE', true );
define( 'MULTISITE', true );
define( 'SUBDOMAIN_INSTALL', false );
define( 'DOMAIN_CURRENT_SITE', 'localhost' );
define( 'PATH_CURRENT_SITE', '/wp-pdf-builder-pro/' );
define( 'SITE_ID_CURRENT_SITE', 1 );
define( 'BLOG_ID_CURRENT_SITE', 1 );
*/

// ** Configuration avancée pour les développeurs ** //
/** Afficher toutes les erreurs PHP */
ini_set( 'display_errors', 1 );
ini_set( 'display_startup_errors', 1 );
error_reporting( E_ALL );

// ** Configuration FTP pour les déploiements automatiques ** //
/*
define( 'FTP_HOST', 'votre-serveur-ftp.com' );
define( 'FTP_USER', 'votre-username' );
define( 'FTP_PASS', 'votre-mot-de-passe' );
define( 'FTP_SSL', true );
*/

// ** C'est tout, ne touchez pas à ce qui suit ! Bonne publication. ** //

/** Chemin absolu vers le dossier de WordPress. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Réglages personnalisés. */
require_once( ABSPATH . 'wp-settings.php' );
?>
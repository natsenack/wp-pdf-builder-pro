<?php
/**
 * Outil de Diagnostic API - PDF Builder Pro
 * Utilitaire pour diagnostiquer les problèmes API
 */

if (!defined('ABSPATH')) {
    exit('Accès direct interdit.');
}

// Simuler un environnement WordPress basique
define('WP_USE_THEMES', false);
require_once('../../../wp-load.php');

echo "<h1>Outil de Diagnostic API - PDF Builder Pro</h1>";
echo "<pre>";

// Vérifier les endpoints REST
echo "=== ENDPOINTS REST ===\n";
$endpoints = [
    '/wp-json/wp/v2/users/me',
    '/wp-json/pdf-builder-pro/v1/status',
    '/wp-json/pdf-builder-pro/v1/templates'
];

foreach ($endpoints as $endpoint) {
    $response = wp_remote_get(rest_url($endpoint));
    $status = wp_remote_retrieve_response_code($response);
    echo "Endpoint: $endpoint - Status: $status\n";
}

// Vérifier les capacités utilisateur
echo "\n=== CAPACITÉS UTILISATEUR ===\n";
$current_user = wp_get_current_user();
echo "Utilisateur connecté: " . ($current_user->ID ? 'Oui' : 'Non') . "\n";
echo "Rôles: " . implode(', ', $current_user->roles) . "\n";

// Vérifier les tables de base de données
echo "\n=== TABLES BASE DE DONNÉES ===\n";
global $wpdb;
$tables = [
    $wpdb->prefix . 'pdf_builder_templates',
    $wpdb->prefix . 'pdf_builder_settings'
];

foreach ($tables as $table) {
    $exists = $wpdb->get_var("SHOW TABLES LIKE '$table'") === $table;
    echo "Table $table: " . ($exists ? 'Existe' : 'N\'existe pas') . "\n";
}

echo "\n=== CONSTANTES ===\n";
echo "WP_DEBUG: " . (WP_DEBUG ? 'Activé' : 'Désactivé') . "\n";
echo "PDF_BUILDER_DEBUG: " . (defined('PDF_BUILDER_DEBUG') && PDF_BUILDER_DEBUG ? 'Activé' : 'Désactivé') . "\n";

echo "</pre>";
?>
# Outils de Développement - PDF Builder Pro

Ce dossier contient des outils de développement et de diagnostic pour PDF Builder Pro.

## 📁 Structure

```
tools/
├── api-diagnostic.php      # Outil de diagnostic API
├── wp-config-sample.php    # Configuration WordPress exemple
└── clear-opcache.php       # Script de vidage du cache OPcache

build-tools/
├── package.json           # Dépendances de build alternatives
└── webpack.config.js      # Configuration webpack alternative
```

## 🔧 Utilisation

### Diagnostic API
Accédez à `tools/api-diagnostic.php` dans votre navigateur pour diagnostiquer :
- Endpoints REST WordPress
- Capacités utilisateur
- Tables de base de données
- Constantes de configuration

### Configuration WordPress
1. Copiez `tools/wp-config-sample.php` vers `wp-config.php`
2. Ajustez les valeurs de base de données
3. Modifiez les constantes selon vos besoins

### Vidage Cache OPcache
Exécutez `tools/clear-opcache.php` pour vider le cache OPcache de PHP.

### Build Alternatif
Si la configuration principale ne fonctionne pas :
```bash
cd build-tools
npm install
npm run build
```

## ⚠️ Sécurité

- `api-diagnostic.php` : À supprimer en production
- `wp-config-sample.php` : Contient des valeurs d'exemple, ne pas utiliser tel quel
- `clear-opcache.php` : Utilitaire de développement uniquement

## 📝 Notes

Ces outils ont été réorganisés depuis les dossiers `dev-tools/` et `build-tools-alt/` originaux pour une meilleure structure de projet.
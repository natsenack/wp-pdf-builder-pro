# 🚀 GUIDE DES SCRIPTS DE DÉPLOIEMENT
# ===================================

## 📊 COMPARAISON DES SOLUTIONS

| Méthode | Vitesse | Complexité | Avantages | Inconvénients |
|---------|---------|------------|-----------|---------------|
| **FTP (ftp-deploy-simple.ps1)** | 0.33 f/s | ⚡ Simple | Fonctionne partout | Limité par serveur |
| **SSH Posh-SSH (ssh-deploy-posh.ps1)** | 5+ f/s | 🔧 Moyen | Ultra-rapide, sécurisé | Nécessite Posh-SSH |
| **WinSCP (winscp-deploy.ps1)** | 2-10 f/s | 🖥️ Interface | Graphique + scriptable | Installation requise |

## 🎯 RECOMMANDATIONS

### Pour le travail quotidien :
```powershell
# Interface graphique simple et efficace
.\winscp-deploy.ps1
```

### Pour l'automatisation :
```powershell
# Scripts PowerShell que nous avons testés
.\ssh-deploy-posh.ps1
```

### Solution de secours :
```powershell
# Quand rien d'autre ne fonctionne
.\ftp-deploy-simple.ps1 -Mode Parallel
```

## 🔧 INSTALLATION REQUISE

### Pour SSH Posh-SSH :
```powershell
Install-Module -Name Posh-SSH -Scope CurrentUser -Force
```

### Pour WinSCP :
- Téléchargez : https://winscp.net/
- Installation standard

## 📝 UTILISATION DÉTAILLÉE

### 1. FTP (Solution actuelle)
```powershell
# Déploiement parallèle optimisé
.\ftp-deploy-simple.ps1 -Mode Parallel

# Paramètres disponibles :
# -Timeout : Timeout en ms (défaut 1000)
# -MaxParallel : Connexions parallèles (défaut 6)
# -PreloadBuffer : Fichiers préchargés (défaut 10)
```

### 2. SSH Posh-SSH (Recommandé)
```powershell
# Déploiement ultra-rapide
.\ssh-deploy-posh.ps1

# Paramètres disponibles :
# -MaxParallel : Connexions parallèles (défaut 4)
# -DryRun : Simulation sans transfert
# -Delete : Supprime fichiers inexistants
```

### 3. WinSCP (Interface graphique)
```powershell
# Générer le script seulement
.\winscp-deploy.ps1 -GenerateScript

# Exécuter directement la synchronisation
.\winscp-deploy.ps1
```

## 🔐 SÉCURITÉ ET CONFIGURATION

### ⚠️ Sécurité renforcée
**NE JAMAIS commiter les mots de passe !** Le fichier `ftp-config.env` ne contient plus de mots de passe.

### Configuration recommandée :
```powershell
# Définir les variables d'environnement (session actuelle)
$env:FTP_HOST = "65.108.242.181"
$env:FTP_USER = "nats"
$env:FTP_PASSWORD = "votre-mot-de-passe-sécurisé"

# Ou pour les rendre permanentes (PowerShell profile)
# Ajoutez ces lignes à $PROFILE
```

### Alternative interactive :
Si vous ne définissez pas `$env:FTP_PASSWORD`, les scripts vous demanderont le mot de passe de manière sécurisée (masqué à l'écran).

## 📊 PERFORMANCES ATTENDUES

- **FTP** : 0.33 fichiers/s (limitation serveur Hetzner)
- **SSH Posh-SSH** : 5+ fichiers/s (théorique)
- **WinSCP** : 2-10 fichiers/s (selon configuration)

## 🔍 DIAGNOSTIC

Pour tester la connectivité :
```powershell
# Test FTP
Test-NetConnection -ComputerName $env:FTP_HOST -Port 21

# Test SSH (si disponible)
Test-NetConnection -ComputerName $env:FTP_HOST -Port 22
```

## 🚨 DÉPANNAGE

### Erreur Posh-SSH :
```
Install-Module -Name Posh-SSH -Scope CurrentUser -Force
```

### Erreur WinSCP :
- Vérifiez l'installation
- Vérifiez les credentials FTP
- Consultez le log `winscp-deploy.log`

### Erreur FTP :
- Vérifiez la connectivité réseau
- Testez avec timeout plus élevé
- Utilisez `-NoParallel` pour debug

## 🔄 VERSIONNAGE AUTOMATIQUE

Tous les scripts effectuent automatiquement :
- `git add .`
- `git commit -m "Deploy YYYY-MM-DD HH:mm:ss"`
- `git push origin dev`

## ⚠️ RECOMMANDATIONS FINALES

1. **Testez d'abord** avec `-DryRun` ou `-GenerateScript`
2. **Videz le cache WordPress** après chaque déploiement
3. **Surveillez les performances** avec les métriques affichées
4. **Utilisez SSH** dès que possible pour la vitesse
5. **Gardez FTP** comme solution de secours

---

*Généré automatiquement - $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')*
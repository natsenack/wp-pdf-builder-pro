<?php
/**
 * Autoload basique pour Dompdf
 */
spl_autoload_register(function ($class) {
    if (strpos($class, 'Dompdf\\') === 0) {
        $class = str_replace('Dompdf\\', '', $class);
        $file = __DIR__ . '/dompdf/src/' . str_replace('\\', '/', $class) . '.php';
        if (file_exists($file)) {
            require_once $file;
        }
    }
});